---
description: "收到专利代理稿要审稿、复核返稿、检查权利要求的说明书支持、核对图文一致性或判断技术效果是否有依据时使用。支持申请人审阅申请前稿，也支持使用方审阅公开或授权文本。核查权项引用、附图、工况和独立项检索证据，输出可追溯的离线 HTML 审核报告，可按需导出 Word 批注版和清洁版。Use for pre-filing patent draft review, revision review, claim support, claim dependencies, drawing consistency, or technical evidence gaps."
name: "patent-draft-review"
display_name: "专利审稿"
display_name_en: "Patent Draft Review"
description_zh: "审核专利稿件和公开文本。核对技术问题、权项方案和效果依据，提示关键缺口，交付可筛选的离线报告。"
description_en: "Review patent drafts and published texts. Trace technical problems, claim features, and supported effects in a filterable offline report."
examples_zh:
  - "审核这份专利代理稿，核对技术问题、权项方案和效果。列出关键证据缺口。"
  - "用包内虚构种苗箱例子生成因果核查报告。"
examples_en:
  - "Review this patent draft and trace the technical problem, claim features, and evidence for the claimed effect."
  - "Render the bundled fictional seedling chamber report."
version: "0.6.1"
author: "KrisMiao97"
---

# 专利审稿

用 [审稿与证据](references/review-method.md) 审核明确版本的申请材料。每次功能性审稿必读并执行 [技术因果必查](references/causal-review.md)，在润色和候选改写前完成问题及权项清单、逐条因果对应和缺证据意见。涉及附图、尺寸、控制条件或备选路径时读 [图文与工况核对](references/technical-review.md)。组织交付时读 [专利审核报告](references/report-output.md) 与 [输出设计规范](DESIGN.md)，模板扩展字段见 [数据与组件](references/template-schema.md)。要求 Word 时另读 [Word 双版本](references/word-output.md)。

1. **先锁定立场、法域、版本和阶段。** 申请人审稿侧重修改决策，使用方审阅第三方专利侧重保护范围、产品对应及证据风险。记录材料版本和程序；公开文本不能代替现行权项。中国规则不直接套用于外国案件，外国规则先查对应官方来源。收集交底、权利要求、说明书、附图、摘要、申请信息和检索材料。缺件继续审可核部分并记录缺口。
2. **分别还原实际方案与权项文字。** 技术解释写清部件装在哪里、在什么条件下怎样运动或配合。权项逐项保留原句、引用关系、累计限定和项内选择。择一引用按路径展开。说明书解释及研发确认单独关联，不能补进原权项记录。
3. **先核技术因果，再全稿审查并按独立项检索。** 以原文列全独权，核对权项速览、独权检索和因果记录。未检索也要登记独权，已有权项记录不得按不适用跳过。分别核实问题及原因、方案怎样改变原因、效果及成立条件，并执行[输入信息、方案选型与效果精度](references/causal-review.md#输入信息方案选型与效果精度)三项反查。关键依据缺失或矛盾时在首页列高优先级意见。实际打开可读的附图，逐图记录页码、可见关系及未核原因。遇阈值、动作切换、故障或例外，列工况表，检查区间、端点、初始状态和适用分支。用可用的智慧芽工具、公开原文或用户给定文献。仅做本地审稿时标明未检索。新颖性与创造性分别记录检索范围、证据和判断。
4. **逐条记录摘要、证据、判断和改法。** 摘要先说要核实什么及其影响，再给原文位置、具体问题、关联图证、法律判断和建议。每处引用写到能复核的页、项、段或图。每项改法在候选文字前标明适用阶段，另列落点、操作、采纳条件和同步位置。涉及权项范围选择时，按 [三档改法与组合依据](references/amendment-options.md) 提出保守澄清、平衡限定和收窄后备。每条后备权项给出完整候选文字、累计引用路径、逐特征出处及同一实施例的组合依据，说明省略特征和冲突。材料不足时列明缺口，不为凑齐三档拼接实施例。待核事项、处理进度和法律判断分别记录。
5. **从统一模板交付并验收。** 首页先给结论、最多四项优先待办和关键缺口。用稳定意见编号关联权项和附图，实走“概览 → 意见 → 图证／改法 → 返回”的路径。结构化数据交给包内生成器；不在生成后的 HTML 上串接案件专用替换。优先保留离线内嵌原图。文件交付和人工复核分开写。要求 Word 且有核验的可编辑基线时，再生成双版本；正文只应用已采纳且适合当前程序的改法。
6. **返稿按问题复核。** 对技术因果缺口重新核查整条关系；缩小效果、放弃目标或改换方案须明示，不能仅凭文字删改认定原缺口已解决。对照原意见逐条记录解决状态。重算受影响路径，重新评价变动的独权和文献判断。旧记录保留版本。重大风险或实质改写回看原文并核对组合证据。

7. **收到报告复审意见时先核实，再固化通用规则。** 同时检查源数据、生成器和实际页面。重复显示的数字若来自同一计算结果，不认定为多处手写。界面修订逐字比对原文摘录、法律判断与内嵌图像，实测体积后再讨论压缩。改通用模板时用另一案件或虚构数据检查空记录、不同状态和缺少关联证据，避免把本案的条数、文献号或法域写死。见 [复审与验收](references/report-validation.md)。

本包维护版本以本目录及用户指定发布包为准。继续修改前保留真实基线。v0.6.1 沿用 schema 4，在现有记录中补强因果适用性与独权覆盖校验。新版速览填写结构化 `claim_type`，既有类型可辨的记录无须换版。缺因果记录的旧数据 1／2／3 仍可阅读，首页提示未完成本项核查。离线生成只需 Python 3.10+，视觉验收另需可用浏览器。

交付前对照 [报告验收](references/report-output.md#交付验收)。核对意见的原文、适用依据和修改落点，抽查附图、工况出处与网页操作。Word 单独记为已交、未要求或未生成并说明原因。声称已生成时核验两份正文一致及批注状态。

## 在 WorkBuddy 中运行

正式审稿先读 @references/causal-review.md 和 @references/review-method.md。报告字段见 @references/template-schema.md。

有 Python 3.10+ 时，从技能目录生成虚构演示。

```text
python scripts/render_review.py examples/template-input.json --output demo-review.html
```

也可直接打开包内 `examples/example-report.html`。无法生成 HTML 时按同一字段交付 Markdown。
