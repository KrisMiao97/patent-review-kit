---
description: "从申请人或使用方立场审阅专利申请稿、返稿及公开或授权文本。先核对法域、程序和文本版本，再核查权项路径、图文、工况及独立项检索证据。交付带筛选、证据跳转和内嵌原图的离线专利审核报告；输出设计规范与模板统一维护，可按需导出 Word 批注版和清洁版。"
name: "patent-draft-review"
display_name: "专利审稿"
display_name_en: "Patent Draft Review"
description_zh: "从申请人或使用方立场审阅专利稿件和公开文本。核对权利要求引用路径、说明书、附图和工况，交付可筛选、可追溯的离线审核报告。"
description_en: "Review patent drafts and published texts from the applicant’s or downstream user’s perspective. Trace claim dependencies, specification support, drawings, and operating conditions in an interactive offline report."
examples_zh:
  - "用包内虚构种苗箱示例生成审核报告，演示意见、权项证据、工况和修改建议之间的跳转。"
  - "审核我提供的代理稿，核对权项引用和图文支持，并按优先级列出原文、理由和候选改法。"
  - "从产品使用方立场审阅这份公开专利，按法域和文本版本标出待核的范围与证据。"
examples_en:
  - "Render the included fictional seedling chamber example and show how issues link to claims, operating conditions, and proposed edits."
  - "Review my draft for claim dependencies and drawing support. Prioritize issues with source excerpts, reasoning, and proposed edits."
  - "Review this published patent from a downstream product user’s perspective. Identify open scope and evidence questions by jurisdiction and document version."
version: "0.4.0"
author: "KrisMiao97"
---

# 专利审稿

用 [审稿与证据](references/review-method.md) 审核明确版本的申请材料。涉及附图、尺寸、控制条件或备选路径时读 [图文与工况核对](references/technical-review.md)。组织交付时读 [专利审核报告](references/report-output.md) 与 [输出设计规范](DESIGN.md)，模板扩展字段见 [数据与组件](references/template-schema.md)。要求 Word 时另读 [Word 双版本](references/word-output.md)。

1. **先锁定立场、法域、版本和阶段。** 申请人审稿侧重修改决策，使用方审阅第三方专利侧重保护范围、产品对应及证据风险。记录材料版本和程序；公开文本不能代替现行权项。中国规则不直接套用于外国案件，外国规则先查对应官方来源。收集交底、权利要求、说明书、附图、摘要、申请信息和检索材料。缺件继续审可核部分并记录缺口。
2. **分别还原实际方案与权项文字。** 技术解释写清部件装在哪里、在什么条件下怎样运动或配合。权项逐项保留原句、引用关系、累计限定和项内选择。择一引用按路径展开。说明书解释及研发确认单独关联，不能补进原权项记录。
3. **全稿审查并按独立项检索。** 实际打开可读的附图，逐图记录页码、可见关系及未核原因。遇阈值、动作切换、故障或例外，列工况表，检查区间、端点、初始状态和适用分支。用可用的智慧芽工具、公开原文或用户给定文献。仅做本地审稿时标明未检索。新颖性与创造性分别记录检索范围、证据和判断。
4. **逐条记录摘要、证据、判断和改法。** 摘要先说要核实什么及其影响，再给原文位置、具体问题、关联图证、法律判断和建议。每处引用写到能复核的页、项、段或图。每项改法在候选文字前标明适用阶段，另列落点、操作、采纳条件和同步位置。待核事项、处理进度和法律判断分别记录。
5. **从统一模板交付并验收。** 首页先给结论、最多四项优先待办和关键缺口。用稳定意见编号关联权项和附图，实走“概览 → 意见 → 图证／改法 → 返回”的路径。结构化数据交给包内生成器；不在生成后的 HTML 上串接案件专用替换。优先保留离线内嵌原图。文件交付和人工复核分开写。要求 Word 且有核验的可编辑基线时，再生成双版本；正文只应用已采纳且适合当前程序的改法。
6. **返稿按问题复核。** 对照原意见逐条记录解决状态。重算受影响路径，重新评价变动的独权和文献判断。旧记录保留版本。重大风险或实质改写回看原文并核对组合证据。

7. **收到报告复审意见时先核实，再固化通用规则。** 同时检查源数据、生成器和实际页面。重复显示的数字若来自同一计算结果，不认定为多处手写。界面修订逐字比对原文摘录、法律判断与内嵌图像，实测体积后再讨论压缩。改通用模板时用另一案件或虚构数据检查空记录、不同状态和缺少关联证据，避免把本案的条数、文献号或法域写死。见 [复审与验收](references/report-validation.md)。

本包维护版本以本目录及用户指定发布包为准；继续修改前保留真实基线。v0.4.0 提供通用报告模板，沿用 schema 3 并兼容旧数据 1／2。离线生成只需 Python 3.10+，视觉验收另需可用浏览器。

交付前对照 [报告验收](references/report-output.md#交付验收)。核对意见的原文、适用依据和修改落点，抽查附图、工况出处与网页操作。Word 单独记为已交、未要求或未生成并说明原因。声称已生成时核验两份正文一致及批注状态。

## 在 WorkBuddy 中运行

审核方法和交付字段见 @references/review-method.md、@references/technical-review.md、@references/report-output.md 和 @references/template-schema.md。需要 Word 时读 @references/word-output.md。

能运行 Python 3.10+ 时，从技能目录执行下面的离线演示命令，输出文件使用一个新路径。

```text
python scripts/render_review.py examples/template-input.json --output demo-review.html
```

Python 不可用时，仍可打开包内 `examples/example-report.html` 浏览虚构演示。正式审稿按相同字段输出 Markdown。Word 导出以可编辑基线、已确认采纳项和兼容文档工具为条件。
